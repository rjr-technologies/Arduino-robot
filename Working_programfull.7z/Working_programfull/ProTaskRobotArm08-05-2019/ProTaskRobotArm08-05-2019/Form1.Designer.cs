﻿namespace ProTaskRobotArm08_05_2019
{
    partial class Robotarm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Robotarm));
            this.tmrLoadRsch = new System.Windows.Forms.Timer(this.components);
            this.tabBeginRJR = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.prbLoadRsch = new System.Windows.Forms.ProgressBar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabAllRsch = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mv_horizon_LL = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.mv_height_D = new System.Windows.Forms.Button();
            this.mv_height_U = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.arm_status_C = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.arm_status_O = new System.Windows.Forms.Button();
            this.mv_claw_arm_B = new System.Windows.Forms.Button();
            this.mv_claw_arm_F = new System.Windows.Forms.Button();
            this.mv_horizon_R = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnCordsRjr = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.lsbCordsRjr = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.timercount = new System.Windows.Forms.Timer(this.components);
            this.tabBeginRJR.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tabAllRsch.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmrLoadRsch
            // 
            this.tmrLoadRsch.Tick += new System.EventHandler(this.tmrLoadRsch_Tick);
            // 
            // tabBeginRJR
            // 
            this.tabBeginRJR.Controls.Add(this.tabPage4);
            this.tabBeginRJR.Controls.Add(this.tabPage5);
            this.tabBeginRJR.Location = new System.Drawing.Point(0, 0);
            this.tabBeginRJR.Name = "tabBeginRJR";
            this.tabBeginRJR.SelectedIndex = 0;
            this.tabBeginRJR.Size = new System.Drawing.Size(788, 461);
            this.tabBeginRJR.TabIndex = 4;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.prbLoadRsch);
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(780, 432);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Start";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // prbLoadRsch
            // 
            this.prbLoadRsch.Location = new System.Drawing.Point(21, 307);
            this.prbLoadRsch.Name = "prbLoadRsch";
            this.prbLoadRsch.Size = new System.Drawing.Size(716, 23);
            this.prbLoadRsch.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ProTaskRobotArm08_05_2019.Properties.Resources.pic;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Location = new System.Drawing.Point(248, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 250);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.menuStrip1);
            this.tabPage5.Controls.Add(this.tabAllRsch);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(780, 432);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "control pannel";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.manualToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(3, 3);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(774, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(62, 24);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // manualToolStripMenuItem
            // 
            this.manualToolStripMenuItem.Name = "manualToolStripMenuItem";
            this.manualToolStripMenuItem.Size = new System.Drawing.Size(70, 24);
            this.manualToolStripMenuItem.Text = "Manual";
            this.manualToolStripMenuItem.Click += new System.EventHandler(this.manualToolStripMenuItem_Click);
            // 
            // tabAllRsch
            // 
            this.tabAllRsch.Controls.Add(this.tabPage1);
            this.tabAllRsch.Controls.Add(this.tabPage2);
            this.tabAllRsch.Location = new System.Drawing.Point(3, 34);
            this.tabAllRsch.Name = "tabAllRsch";
            this.tabAllRsch.SelectedIndex = 0;
            this.tabAllRsch.Size = new System.Drawing.Size(766, 376);
            this.tabAllRsch.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(758, 347);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "controls";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.mv_horizon_LL);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.mv_height_D);
            this.groupBox1.Controls.Add(this.mv_height_U);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.arm_status_C);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.arm_status_O);
            this.groupBox1.Controls.Add(this.mv_claw_arm_B);
            this.groupBox1.Controls.Add(this.mv_claw_arm_F);
            this.groupBox1.Controls.Add(this.mv_horizon_R);
            this.groupBox1.Location = new System.Drawing.Point(3, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 311);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Claw controls";
            // 
            // mv_horizon_LL
            // 
            this.mv_horizon_LL.Location = new System.Drawing.Point(11, 38);
            this.mv_horizon_LL.Name = "mv_horizon_LL";
            this.mv_horizon_LL.Size = new System.Drawing.Size(114, 46);
            this.mv_horizon_LL.TabIndex = 14;
            this.mv_horizon_LL.Text = "<";
            this.mv_horizon_LL.UseVisualStyleBackColor = true;
            this.mv_horizon_LL.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mv_horizon_LL_MouseDown_1);
            this.mv_horizon_LL.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mv_horizon_LL_MouseUp);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 18);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 17);
            this.label13.TabIndex = 13;
            this.label13.Text = "turn claw";
            // 
            // mv_height_D
            // 
            this.mv_height_D.Location = new System.Drawing.Point(131, 105);
            this.mv_height_D.Name = "mv_height_D";
            this.mv_height_D.Size = new System.Drawing.Size(114, 46);
            this.mv_height_D.TabIndex = 12;
            this.mv_height_D.Text = "down";
            this.mv_height_D.UseVisualStyleBackColor = true;
            this.mv_height_D.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button5_MouseDown);
            this.mv_height_D.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button5_MouseUp);
            // 
            // mv_height_U
            // 
            this.mv_height_U.Location = new System.Drawing.Point(11, 105);
            this.mv_height_U.Name = "mv_height_U";
            this.mv_height_U.Size = new System.Drawing.Size(114, 46);
            this.mv_height_U.TabIndex = 11;
            this.mv_height_U.Text = "up";
            this.mv_height_U.UseVisualStyleBackColor = true;
            this.mv_height_U.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mv_height_U_MouseDown);
            this.mv_height_U.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mv_height_U_MouseUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "claw height";
            // 
            // arm_status_C
            // 
            this.arm_status_C.Location = new System.Drawing.Point(131, 247);
            this.arm_status_C.Name = "arm_status_C";
            this.arm_status_C.Size = new System.Drawing.Size(114, 46);
            this.arm_status_C.TabIndex = 5;
            this.arm_status_C.Text = "close";
            this.arm_status_C.UseVisualStyleBackColor = true;
            this.arm_status_C.MouseDown += new System.Windows.Forms.MouseEventHandler(this.arm_status_C_MouseDown);
            this.arm_status_C.MouseUp += new System.Windows.Forms.MouseEventHandler(this.arm_status_C_MouseUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "claw arm";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 227);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "claw";
            // 
            // arm_status_O
            // 
            this.arm_status_O.Location = new System.Drawing.Point(11, 247);
            this.arm_status_O.Name = "arm_status_O";
            this.arm_status_O.Size = new System.Drawing.Size(114, 46);
            this.arm_status_O.TabIndex = 6;
            this.arm_status_O.Text = "open";
            this.arm_status_O.UseVisualStyleBackColor = true;
            this.arm_status_O.MouseDown += new System.Windows.Forms.MouseEventHandler(this.arm_status_O_MouseDown);
            this.arm_status_O.MouseUp += new System.Windows.Forms.MouseEventHandler(this.arm_status_O_MouseUp);
            // 
            // mv_claw_arm_B
            // 
            this.mv_claw_arm_B.Location = new System.Drawing.Point(131, 174);
            this.mv_claw_arm_B.Name = "mv_claw_arm_B";
            this.mv_claw_arm_B.Size = new System.Drawing.Size(114, 46);
            this.mv_claw_arm_B.TabIndex = 3;
            this.mv_claw_arm_B.Text = "retract";
            this.mv_claw_arm_B.UseVisualStyleBackColor = true;
            this.mv_claw_arm_B.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mv_claw_arm_B_MouseDown);
            this.mv_claw_arm_B.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mv_claw_arm_B_MouseUp);
            // 
            // mv_claw_arm_F
            // 
            this.mv_claw_arm_F.Location = new System.Drawing.Point(11, 174);
            this.mv_claw_arm_F.Name = "mv_claw_arm_F";
            this.mv_claw_arm_F.Size = new System.Drawing.Size(114, 46);
            this.mv_claw_arm_F.TabIndex = 7;
            this.mv_claw_arm_F.Text = "extent";
            this.mv_claw_arm_F.UseVisualStyleBackColor = true;
            this.mv_claw_arm_F.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mv_claw_arm_F_MouseDown);
            this.mv_claw_arm_F.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mv_claw_arm_F_MouseUp);
            // 
            // mv_horizon_R
            // 
            this.mv_horizon_R.Location = new System.Drawing.Point(131, 37);
            this.mv_horizon_R.Name = "mv_horizon_R";
            this.mv_horizon_R.Size = new System.Drawing.Size(114, 46);
            this.mv_horizon_R.TabIndex = 7;
            this.mv_horizon_R.Text = ">";
            this.mv_horizon_R.UseVisualStyleBackColor = true;
            this.mv_horizon_R.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mv_horizon_R_MouseDown);
            this.mv_horizon_R.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mv_horizon_R_MouseUp);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(305, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(331, 244);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "information";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(249, 187);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 51);
            this.button4.TabIndex = 31;
            this.button4.Text = "Pos4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(168, 187);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 51);
            this.button3.TabIndex = 30;
            this.button3.Text = "Pos3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(87, 187);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 51);
            this.button6.TabIndex = 29;
            this.button6.Text = "Pos2";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 187);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 51);
            this.button2.TabIndex = 25;
            this.button2.Text = "Pos1";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 17);
            this.label11.TabIndex = 24;
            this.label11.Text = "Claw:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(198, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 84);
            this.button1.TabIndex = 14;
            this.button1.Text = "Reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(66, 49);
            this.label10.MaximumSize = new System.Drawing.Size(45, 79);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(12, 17);
            this.label10.TabIndex = 15;
            this.label10.Text = ".";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 17);
            this.label9.TabIndex = 14;
            this.label9.Text = "Turn:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 17);
            this.label8.TabIndex = 13;
            this.label8.Text = "extend:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Height:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "coordinates";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnCordsRjr);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.lsbCordsRjr);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(758, 347);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "position";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnCordsRjr
            // 
            this.btnCordsRjr.Location = new System.Drawing.Point(27, 267);
            this.btnCordsRjr.Name = "btnCordsRjr";
            this.btnCordsRjr.Size = new System.Drawing.Size(394, 23);
            this.btnCordsRjr.TabIndex = 2;
            this.btnCordsRjr.Text = "Save coordinates";
            this.btnCordsRjr.UseVisualStyleBackColor = true;
            this.btnCordsRjr.Click += new System.EventHandler(this.btnCordsRjr_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 17);
            this.label14.TabIndex = 1;
            this.label14.Text = "last coordinates";
            // 
            // lsbCordsRjr
            // 
            this.lsbCordsRjr.FormattingEnabled = true;
            this.lsbCordsRjr.ItemHeight = 16;
            this.lsbCordsRjr.Location = new System.Drawing.Point(6, 33);
            this.lsbCordsRjr.Name = "lsbCordsRjr";
            this.lsbCordsRjr.Size = new System.Drawing.Size(452, 228);
            this.lsbCordsRjr.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // timercount
            // 
            this.timercount.Interval = 50;
            this.timercount.Tick += new System.EventHandler(this.timercount_Tick);
            // 
            // Robotarm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(789, 463);
            this.Controls.Add(this.tabBeginRJR);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Robotarm";
            this.Text = "Arduino robot";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Robotarm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Robotarm_FormClosed);
            this.tabBeginRJR.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabAllRsch.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer tmrLoadRsch;
        private System.Windows.Forms.TabControl tabBeginRJR;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ProgressBar prbLoadRsch;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tabAllRsch;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button mv_horizon_LL;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button mv_height_D;
        private System.Windows.Forms.Button mv_height_U;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button arm_status_C;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button arm_status_O;
        private System.Windows.Forms.Button mv_claw_arm_B;
        private System.Windows.Forms.Button mv_claw_arm_F;
        private System.Windows.Forms.Button mv_horizon_R;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ListBox lsbCordsRjr;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manualToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Timer timercount;
        private System.Windows.Forms.Button btnCordsRjr;
    }
}

