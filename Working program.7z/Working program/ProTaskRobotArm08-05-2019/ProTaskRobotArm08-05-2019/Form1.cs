﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;
namespace ProTaskRobotArm08_05_2019
{
    public partial class Robotarm : Form
    {
        SerialPort port;
        public Robotarm()
        {
            InitializeComponent();
            tabBeginRJR.Appearance = TabAppearance.FlatButtons;
            tabBeginRJR.ItemSize = new Size(0, 2);
            tabBeginRJR.SizeMode = TabSizeMode.Fixed;
            tmrLoadRsch.Start();
            this.FormClosed += new FormClosedEventHandler(Form1_FormClosed);
            if (port == null)
            {
                port = new SerialPort("COM3", 115200);//Set your board COM
                port.Open();
            }
        }
        void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (port != null && port.IsOpen)
            {
                port.Close();
            }
        }

        private void PortWrite(string message)
        {
            port.Write(message);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //PortWrite("hello");
            PortWrite("doStartPosition\r\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //PortWrite("trout");
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            label20.Text = "hold";
            // PortWrite("doMoveDown\n");
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            label20.Text = "release";
            // PortWrite("doArmHold\r\n");
        }

        private void mv_height_U_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveUp\r\n");
        }

        private void bmv_height_U_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveDown\r\n");
        }

        private void button5_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void mv_height_U_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void mv_horizon_LL_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveLeft\r\n");
        }

        private void mv_horizon_LL_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void mv_horizon_R_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveRight\r\n");
        }

        private void mv_horizon_R_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }   

        private void mv_claw_arm_F_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmForward\r\n");
        }

        private void mv_claw_arm_F_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void mv_claw_arm_B_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmBackward\r\n");
        }

        private void mv_claw_arm_B_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void arm_status_O_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmOpened\r\n");
        }

        private void arm_status_O_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void arm_status_C_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmClosed\r\n");
        }

        private void arm_status_C_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            tmrLoadRsch.Start();

        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            //string line = port.ReadLine();
           //this.BeginInvoke(new LineReceivedEvent(LineReceived), line);
        }

        private delegate void LineReceivedEvent(string line);
        private void LineReceived(string line)
        {

            label20.Text = line;
        }

        private void mv_horizon_LL_MouseDown_1(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveLeft\r\n");
        }
        
        private void tmrLoadRsch_Tick(object sender, EventArgs e)
        {
            prbLoadRsch.Value = prbLoadRsch.Value + 10;
            if (prbLoadRsch.Value == prbLoadRsch.Maximum)
            {
                tmrLoadRsch.Stop();
                tabBeginRJR.SelectedIndex = 1;
                prbLoadRsch.Value = 0;
                
            }
            if(prbLoadRsch.Value > 5)
            {
                PortWrite("doStartPosition\r\n");
                //label20.Text = "adsfasdfasdf";
            }
        }
    }
}
