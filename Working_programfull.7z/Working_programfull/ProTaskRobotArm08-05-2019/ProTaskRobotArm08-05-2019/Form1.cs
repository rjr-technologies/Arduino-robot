﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;
using System.IO;

namespace ProTaskRobotArm08_05_2019
{
    public partial class Robotarm : Form
    {
        SerialPort port;
        string InputData = String.Empty;
        string corddata = "";
        delegate void SetTextCallback(string text);

        bool var1 = false;
        bool var2 = false;
        bool var3 = false;
        bool var4 = false;
        int number1 = 0;
        int number2 = 0;
        int number3 = 0;
        int number4 = 0;
        bool start = true;

        public Robotarm()
        {
            InitializeComponent();
            tabBeginRJR.Appearance = TabAppearance.FlatButtons;
            tabBeginRJR.ItemSize = new Size(0, 2);
            tabBeginRJR.SizeMode = TabSizeMode.Fixed;
            tmrLoadRsch.Start();
            this.FormClosed += new FormClosedEventHandler(Form1_FormClosed);
            if (port == null)
            {
                port = new SerialPort("COM3", 115200);//Set your board COM
                port.Open();
                port.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived_1);
            }
        }

        void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (port != null && port.IsOpen)
            {
                port.Close();
            }
        }

        private void PortWrite(string message)
        {
           port.Write(message);
        }

        /// <summary>
        /// resetbutton
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click_1(object sender, EventArgs e)
        {
            //PortWrite("hello");
            PortWrite("doStartPosition\r\n");
            start = true;
        }
        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_height_U_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveUp\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bmv_height_U_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveDown\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_height_U_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_horizon_LL_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveLeft\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_horizon_LL_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_horizon_R_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveRight\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_horizon_R_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_claw_arm_F_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmForward\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_claw_arm_F_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_claw_arm_B_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmBackward\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_claw_arm_B_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void arm_status_O_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmOpened\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void arm_status_O_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }

        private void arm_status_C_MouseDown(object sender, MouseEventArgs e)
        {
            PortWrite("doArmClosed\r\n");
            start = false;
        }
        /// <summary>
        /// send string when the mouse button is released
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void arm_status_C_MouseUp(object sender, MouseEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            //start the timer as soon as the form loads
            tmrLoadRsch.Start();
        }

        /// <summary>
        /// send string when the mouse click is pushed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mv_horizon_LL_MouseDown_1(object sender, MouseEventArgs e)
        {
            PortWrite("doMoveLeft\r\n");
            start = false;
        }
        /// <summary>
        /// send the string that puts the claw in starting position while theres a flash screen loading
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tmrLoadRsch_Tick(object sender, EventArgs e)
        {
            prbLoadRsch.Value = prbLoadRsch.Value + 1;
            if (prbLoadRsch.Value == prbLoadRsch.Maximum)
            {
                tmrLoadRsch.Stop();
                tabBeginRJR.SelectedIndex = 1;
                prbLoadRsch.Value = 0;
            }

            if(prbLoadRsch.Value > 5)
            {
                PortWrite("doStartPosition\r\n");
            }
            if (prbLoadRsch.Value > 95)
            {
                PortWrite("doStartPosition\r\n");
            }
        }
        private void port_DataReceived_1(object sender, SerialDataReceivedEventArgs e)
        {
            InputData = port.ReadExisting();
            if (InputData != String.Empty)
            {
                this.BeginInvoke(new SetTextCallback(SetText), new object[] { InputData });
            }
        }

        public void SetText(string text)
        {
            if (text.IndexOf("$") == 0 && text.IndexOf("@") > 0)
            {
                text = text.Substring(1, text.Length - 3);
                string[] words = text.Split('$');

                foreach (string word in words)
                {
                    label10.Text = word;
                    corddata = word;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (start == true)
            {
                var1 = true;
                start = false;
                timercount.Start();
                mv_horizon_LL.Enabled = false;
                mv_horizon_R.Enabled = false;
                mv_height_U.Enabled = false;
                mv_height_D.Enabled = false;
                mv_claw_arm_F.Enabled = false;
                mv_claw_arm_B.Enabled = false;
                arm_status_O.Enabled = false;
                arm_status_C.Enabled = false;
                button1.Enabled = false;
            }
            else
            {
                MessageBox.Show("claw is not at start position");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (start == true)
            {
                var2 = true;
                start = false;
                timercount.Start();
                mv_horizon_LL.Enabled = false;
                mv_horizon_R.Enabled = false;
                mv_height_U.Enabled = false;
                mv_height_D.Enabled = false;
                mv_claw_arm_F.Enabled = false;
                mv_claw_arm_B.Enabled = false;
                arm_status_O.Enabled = false;
                arm_status_C.Enabled = false;
                button1.Enabled = false;
            }
            else
            {
                MessageBox.Show("claw is not at start position");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (start == true)
            {
                var3 = true;
                start = false;
                timercount.Start();
                mv_horizon_LL.Enabled = false;
                mv_horizon_R.Enabled = false;
                mv_height_U.Enabled = false;
                mv_height_D.Enabled = false;
                mv_claw_arm_F.Enabled = false;
                mv_claw_arm_B.Enabled = false;
                arm_status_O.Enabled = false;
                arm_status_C.Enabled = false;
                button1.Enabled = false;
            }
            else
            {
                MessageBox.Show("claw is not at start position");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (start == true)
            {
                var4 = true;
                start = false;
                timercount.Start();
                mv_horizon_LL.Enabled = false;
                mv_horizon_R.Enabled = false;
                mv_height_U.Enabled = false;
                mv_height_D.Enabled = false;
                mv_claw_arm_F.Enabled = false;
                mv_claw_arm_B.Enabled = false;
                arm_status_O.Enabled = false;
                arm_status_C.Enabled = false;
                button1.Enabled = false;
            }
            else
            {
                MessageBox.Show("claw is not at start position");
            }
        }

        private void timercount_Tick(object sender, EventArgs e)
        {
            if (var1 == true)
            {
                if (number1 < 155)
                {
                    PortWrite("doMoveRight\r\n");
                }
                else if (number1 == 155)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number1 == 156)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number1 < 288)
                {
                    PortWrite("doMoveDown\r\n");
                }
                else if (number1 == 288)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number1 == 289)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number1 < 400)
                {
                    PortWrite("doArmForward\r\n");
                }
                else if (number1 == 400)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number1 == 401)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number1 < 435)
                {
                    PortWrite("doArmClosed\r\n");
                }
                else
                {
                    PortWrite("doArmHold\r\n");
                    timercount.Stop();
                    var1 = false;
                    number1 = 0;
                    mv_horizon_LL.Enabled = true;
                    mv_horizon_R.Enabled = true;
                    mv_height_U.Enabled = true;
                    mv_height_D.Enabled = true;
                    mv_claw_arm_F.Enabled = true;
                    mv_claw_arm_B.Enabled = true;
                    arm_status_O.Enabled = true;
                    arm_status_C.Enabled = true;
                    button1.Enabled = true;
                }
                number1++;
            }
            else if (var2 == true)
            {
                if (number2 < 80)
                {
                    PortWrite("doMoveRight\r\n");
                }
                else if (number2 == 80)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number2 == 81)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number2 < 213)
                {
                    PortWrite("doMoveDown\r\n");
                }
                else if (number2 == 213)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number2 == 214)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number2 < 300)
                {
                    PortWrite("doArmForward\r\n");
                }
                else if (number2 == 300)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number2 == 301)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number2 < 335)
                {
                    PortWrite("doArmClosed\r\n");
                }
                else
                {
                    PortWrite("doArmHold\r\n");
                    timercount.Stop();
                    var2 = false;
                    number2 = 0;
                    mv_horizon_LL.Enabled = true;
                    mv_horizon_R.Enabled = true;
                    mv_height_U.Enabled = true;
                    mv_height_D.Enabled = true;
                    mv_claw_arm_F.Enabled = true;
                    mv_claw_arm_B.Enabled = true;
                    arm_status_O.Enabled = true;
                    arm_status_C.Enabled = true;
                    button1.Enabled = true;
                }
                number2++;
            }
            else if (var3 == true)
            {
                if (number3 < 10)
                {
                    PortWrite("doMoveRight\r\n");
                }
                else if (number3 == 10)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number3 == 11)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number3 < 145)
                {
                    PortWrite("doMoveDown\r\n");
                }
                else if (number3 == 145)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number3 == 146)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number3 < 250)
                {
                    PortWrite("doArmForward\r\n");
                }
                else if (number3 == 250)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number3 == 251)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number3 < 285)
                {
                    PortWrite("doArmClosed\r\n");
                }
                else
                {
                    PortWrite("doArmHold\r\n");
                    timercount.Stop();
                    var3 = false;
                    number3 = 0;
                    mv_horizon_LL.Enabled = true;
                    mv_horizon_R.Enabled = true;
                    mv_height_U.Enabled = true;
                    mv_height_D.Enabled = true;
                    mv_claw_arm_F.Enabled = true;
                    mv_claw_arm_B.Enabled = true;
                    arm_status_O.Enabled = true;
                    arm_status_C.Enabled = true;
                    button1.Enabled = true;
                }
                number3++;
            }
            else if (var4 == true)
            {
                if (number4 < 155)
                {
                    PortWrite("doMoveRight\r\n");
                }
                else if (number4 == 155)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 156)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 288)
                {
                    PortWrite("doMoveDown\r\n");
                }
                else if (number4 == 288)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 289)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 400)
                {
                    PortWrite("doArmForward\r\n");
                }

                else if (number4 == 400)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 401)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 430)
                {
                    PortWrite("doArmClosed\r\n");
                }
                else if (number4 == 430)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 431)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 436)
                {
                    PortWrite("doMoveUp\r\n");
                }
                else if (number4 == 436)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 437)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 548)
                {
                    PortWrite("doArmBackward\r\n");
                }
                else if (number4 == 548)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 549)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 686)
                {
                    PortWrite("doMoveLeft\r\n");
                }
                else if (number4 == 686)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 687)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 787)
                {
                    PortWrite("doArmForward\r\n");
                }
                else if (number4 == 787)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 800)
                {
                    PortWrite("doArmOpened\r\n");
                }
                else if (number4 == 800)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 == 801)
                {
                    PortWrite("doArmHold\r\n");
                }
                else if (number4 < 850)
                {
                    PortWrite("doMoveUp\r\n");
                }
                else
                {
                    PortWrite("doArmHold\r\n");
                    timercount.Stop();
                    var4 = false;
                    number4 = 0;
                    mv_horizon_LL.Enabled = true;
                    mv_horizon_R.Enabled = true;
                    mv_height_U.Enabled = true;
                    mv_height_D.Enabled = true;
                    mv_claw_arm_F.Enabled = true;
                    mv_claw_arm_B.Enabled = true;
                    arm_status_O.Enabled = true;
                    arm_status_C.Enabled = true;
                    button1.Enabled = true;
                }
                number4++;
            }
        }
        

        /// <summary>
        /// if you close the form then the arm stops moving
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Robotarm_FormClosing(object sender, FormClosingEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
        /// <summary>
        /// open the manual text file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void manualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\Beheerder\\Desktop\\School\\Proftaak\\Working_programfull\\ProTaskRobotArm08-05-2019\\protaskmanual.txt");
        }
        /// <summary>
        /// show a messagebox by who this application is created
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("this program was made by Rik van Schaik, Ruby Feller and Jarno Munsters IC18AOE");
        }
        /// <summary>
        /// save the coordinates in the listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void btnCordsRjr_Click(object sender, EventArgs e)
        {
            lsbCordsRjr.Items.Add(" " + corddata + "\n");
        }

        private void Robotarm_FormClosed(object sender, FormClosedEventArgs e)
        {
            PortWrite("doArmHold\r\n");
        }
    }
}
